

import UIKit

class Login: UIViewController
{
    
    @IBOutlet weak var Loginview: UIView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        /*self.Loginview.backgroundColor = UIColor(colorLiteralRed: 17.0/255.0, green: 180.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        self.Loginview.layer.masksToBounds = false
        Loginview.layer.shadowOpacity = 0.5*/
        
        
        self.Loginview.layer.cornerRadius = 10
        Loginview.layer.masksToBounds = false
        Loginview.layer.shadowOffset = CGSize(width: 2, height: 2)
        Loginview.layer.shadowOpacity = 0.5
        Loginview.layer.opacity = 0.7
        
        
      
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
   
    }
    

   

}
