
import UIKit

class ViewController: UIViewController
{

    var time = Timer()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        let nav = navigationController
        nav?.isNavigationBarHidden = true
        
        time = Timer.scheduledTimer(timeInterval: 3, target: self, selector: #selector(self.move), userInfo: nil, repeats: true)
        
       
    }

    func move(sender:Timer)
    {
        time.invalidate()
        
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "tab")
        self.navigationController?.pushViewController(stb!, animated: true)
    }
    
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }


}

